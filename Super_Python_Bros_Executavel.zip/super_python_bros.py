
import pygame
import sys
import random

pygame.init()

WIDTH = 1000
HEIGHT = 600
FPS = 60
GRAVITY = 0.8
JUMP_POWER = -15

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Super Python Bros")
clock = pygame.time.Clock()

WHITE = (255,255,255)
GREEN = (34,177,76)
BLUE = (0,162,232)
GOLD = (255,215,0)

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((40,60))
        self.image.fill((255,0,0))
        self.rect = self.image.get_rect()
        self.rect.x = 100
        self.rect.y = HEIGHT - 150
        
        self.vel_y = 0
        self.speed = 5
        self.on_ground = False

    def update(self, platforms):
        keys = pygame.key.get_pressed()

        if keys[pygame.K_LEFT]:
            self.rect.x -= self.speed

        if keys[pygame.K_RIGHT]:
            self.rect.x += self.speed

        if keys[pygame.K_SPACE] and self.on_ground:
            self.vel_y = JUMP_POWER
            self.on_ground = False

        self.vel_y += GRAVITY
        self.rect.y += self.vel_y

        self.on_ground = False

        for platform in platforms:
            if self.rect.colliderect(platform.rect):
                if self.vel_y > 0:
                    self.rect.bottom = platform.rect.top
                    self.vel_y = 0
                    self.on_ground = True


class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, w, h):
        super().__init__()
        self.image = pygame.Surface((w,h))
        self.image.fill(GREEN)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


class Coin(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((20,20))
        self.image.fill(GOLD)
        self.rect = self.image.get_rect()
        self.rect.center = (x,y)


class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((40,40))
        self.image.fill((0,0,255))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.direction = 1

    def update(self):
        self.rect.x += self.direction * 2
        if self.rect.x < 0 or self.rect.x > WIDTH - 40:
            self.direction *= -1


player = Player()

platforms = pygame.sprite.Group()
coins = pygame.sprite.Group()
enemies = pygame.sprite.Group()
all_sprites = pygame.sprite.Group()

all_sprites.add(player)

platform_data = [
    (0,550,1000,50),
    (200,450,200,20),
    (500,400,200,20),
    (750,300,150,20),
]

for p in platform_data:
    plat = Platform(*p)
    platforms.add(plat)
    all_sprites.add(plat)

for i in range(10):
    coin = Coin(random.randint(100,900), random.randint(100,400))
    coins.add(coin)
    all_sprites.add(coin)

for i in range(3):
    enemy = Enemy(random.randint(200,900),500)
    enemies.add(enemy)
    all_sprites.add(enemy)

font = pygame.font.SysFont("Arial", 30)
score = 0

running = True

while running:
    clock.tick(FPS)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    player.update(platforms)
    enemies.update()

    hit_coins = pygame.sprite.spritecollide(player, coins, True)
    if hit_coins:
        score += len(hit_coins) * 10

    if pygame.sprite.spritecollide(player, enemies, False):
        score = 0
        player.rect.x = 100
        player.rect.y = HEIGHT - 150

    screen.fill(BLUE)
    all_sprites.draw(screen)

    text = font.render(f"Moedas: {score}", True, WHITE)
    screen.blit(text,(20,20))

    pygame.display.flip()

pygame.quit()
sys.exit()
